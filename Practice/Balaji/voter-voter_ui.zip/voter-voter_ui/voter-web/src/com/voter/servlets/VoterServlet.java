package com.voter.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class VoterServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Properties props = new Properties();
		props.load(getServletContext().getResourceAsStream("/WEB-INF/db.properties"));
		String driver = props.getProperty("driver");
		RequestDispatcher rd=null;
		Connection con=null;
		if (driver != null) {
		    try {
				Class.forName(driver) ;
				String dburl = props.getProperty("url");
				String dbusername = props.getProperty("username");
				String dbpassword = props.getProperty("password");
				con = DriverManager.getConnection(dburl, dbusername, dbpassword);
					String get_voters_query="SELECT * FROM VOTERS";
					Statement st= con.createStatement();
					ResultSet rs= st.executeQuery(get_voters_query);
					List<Object> voterobj= new ArrayList<Object>();
					while (rs.next()) {
						Map<String, Object> voters=new HashMap<String, Object>();
						voters.put("id", rs.getInt("id"));
						voters.put("fn", rs.getString("firstName"));
						voters.put("con", rs.getString("contact"));
						voters.put("dob", rs.getString("dob"));
						voterobj.add(voters);
					}
						rd=req.getRequestDispatcher("viewVoters.jsp");
						req.setAttribute("voters",voterobj);						
						rd.forward(req, resp);
			} catch (Exception e) {
				e.printStackTrace();
			}  
		    finally {
				try {
					con.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
