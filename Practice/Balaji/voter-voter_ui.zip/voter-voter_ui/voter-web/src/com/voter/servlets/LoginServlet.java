package com.voter.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Properties props = new Properties();
		props.load(getServletContext().getResourceAsStream("/WEB-INF/db.properties"));
		String driver = props.getProperty("driver");
		Connection con=null;
		if (driver != null) {
		    try {
				Class.forName(driver) ;
				String dburl = props.getProperty("url");
				String dbusername = props.getProperty("username");
				String dbpassword = props.getProperty("password");
				
				RequestDispatcher rd= req.getRequestDispatcher("register_voter.jsp");
				String username= req.getParameter("username");
				String password= req.getParameter("pass");
				con = DriverManager.getConnection(dburl, dbusername, dbpassword);
				
				Statement st= con.createStatement();
				ResultSet rs= st.executeQuery("SELECT * FROM users WHERE user_type='role_admin'");
				if(!rs.next()) {
					String query="INSERT INTO users(username, password, user_type) VALUES('"+username+"','"+password+"','role_admin')";
					int res=st.executeUpdate(query);
					if(res!=0) {
						String message="Welcome Admin";
						req.setAttribute("welmsg", message);
						rd.forward(req, resp);
					}
					else {
						String message="Sorry, Something went wrong";
						req.setAttribute("message ",message);
						rd = req.getRequestDispatcher("welcome.jsp");
						rd.forward(req, resp);
					}
					
				}
				else {
					if(username.equals("admin") && password.equals("superadmin")) {
						String message="Welcome Admin";
						req.setAttribute("welmsg", message);
						rd= req.getRequestDispatcher("register_voter.jsp");
						rd.forward(req, resp);
					}
					else {
						String message="Sorry, Something went wrong";
						req.setAttribute("message",message);
						rd = req.getRequestDispatcher("welcome.jsp");
						rd.forward(req, resp);
					}
					
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		    finally {
				try {
					con.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
