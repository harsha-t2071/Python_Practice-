package com.voter.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DeleteServlet extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Properties props = new Properties();
		props.load(getServletContext().getResourceAsStream("/WEB-INF/db.properties"));
		String driver = props.getProperty("driver");
		RequestDispatcher rd=null;
		Connection con=null;
		if (driver != null) {
		    try {
				Class.forName(driver) ;
				String dburl = props.getProperty("url");
				String dbusername = props.getProperty("username");
				String dbpassword = props.getProperty("password");
				con = DriverManager.getConnection(dburl, dbusername, dbpassword);
				
				String id=req.getParameter("vid");
				if(id!=null) {
					String delete_byId_query="DELETE FROM VOTERS WHERE id='"+id+"'";
					Statement st= con.createStatement();
					int rs= st.executeUpdate(delete_byId_query);
					if(rs>0)
					{
						rd=req.getRequestDispatcher("voters");
						String message="Voter Deleted Successfully";
						req.setAttribute("delsuss",message);						
						rd.forward(req, resp);
					}
					else
					{
						rd=req.getRequestDispatcher("voters");
						String message="Something Went wrong. Please Try again!!";
						req.setAttribute("delfail",message);						
						rd.forward(req, resp);
					}
						 
				}
					
			} catch (Exception e) {
				e.printStackTrace();
			}  
		    
		    finally {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
	 
}
