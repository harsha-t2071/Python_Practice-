package com.voter.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Properties props = new Properties();
		props.load(getServletContext().getResourceAsStream("/WEB-INF/db.properties"));
		String driver = props.getProperty("driver");
		RequestDispatcher rd=null;
		Connection con=null;
		if (driver != null) {
		    try {
				Class.forName(driver) ;
				String dburl = props.getProperty("url");
				String dbusername = props.getProperty("username");
				String dbpassword = props.getProperty("password");
				con = DriverManager.getConnection(dburl, dbusername, dbpassword);
				String firstName= req.getParameter("firstname");
				String lastName= req.getParameter("lastname");
				String contact= req.getParameter("contact");
				String dob= req.getParameter("dob");
				String gender= req.getParameter("gender");
				
				if(firstName!=null && lastName!=null && contact!=null && dob!=null && gender!=null)
				{
					String ins_query="INSERT INTO VOTERS(firstname, lastname, contact, dob, gender) VALUES('"+firstName+"','"+lastName+"','"+contact+"','"+dob+"','"+gender+"')";
					Statement st= con.createStatement();
					int rs= st.executeUpdate(ins_query);
					if(rs>0)
					{
						rd=req.getRequestDispatcher("register_voter.jsp");
						String message="Voter Created Successfully";
						req.setAttribute("regsuss",message);						
						rd.forward(req, resp);
					}
					else
					{
						rd=req.getRequestDispatcher("register_voter.jsp");
						String message="Something Went wrong";
						req.setAttribute("regfail",message);						
						rd.forward(req, resp);
					}
				}
				else
				{
					rd=req.getRequestDispatcher("register_voter.jsp");
					String message="One of the fileds is not right!!";
					req.setAttribute("emptyres",message);						
					rd.forward(req, resp);
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		    finally {
				try {
					con.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
